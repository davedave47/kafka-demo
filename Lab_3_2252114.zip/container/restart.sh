./clean.sh
./build.sh